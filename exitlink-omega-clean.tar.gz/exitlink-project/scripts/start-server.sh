#!/bin/bash

echo "Starting web server on port 12000..."
cd /workspace/8
node server.js